-- Thing.lua
-- Base class module that other game objects (like Creature) inherit from.
-- Shared fields and methods go here.

---@class Thing
---@field ThingIndex integer
---@field creation_turn integer
---@field thing_class string
---@field model string
---@field anim_sprite string AnimationID or Custom sprite name
---@field anim_speed integer
---@field sprite_size integer How big the thing looks. Default size is 300, creatures grow beyond.
---@field sprite_size_min integer If the sprite_size is below min, it will be increased.
---@field sprite_size_max integer If the sprite_size is above max, it will be decreased.
---@field transformation_speed integer Grow the sprite_size by this value each turn.
---@field clipbox_size_xy integer Horizontal hitbox for shots.
---@field clipbox_size_z integer Vertical hitbox for shots.
---@field solid_size_xy integer Horizontal size for navigation.
---@field solid_size_z integer Vertical size for navigation.
---@field pos Pos3d
---@field orientation integer
---@field pitch integer
---@field owner Player
---@field health integer
---@field max_health integer If the health gets beyond this point, it will be decreased.
---@field picked_up boolean
if not Thing then Thing = {} end

---@class Object: Thing
---@field box_kind integer The Custom box number on a special box.
---@field parent Slab|Room|nil ***read-only*** The Slab or room (for chicken) it belongs to.
if not Object then Object = {} end

---@class Corpse: Thing
if not Corpse then Corpse = {} end

---@class Effect: Thing
---@field parent Thing|nil ***read-only*** The thing that created this one.
if not Effect then Effect = {} end

---@class EffectElem: Thing
---@field parent Thing|nil ***read-only*** The thing that created this one.
if not EffectElem then EffectElem = {} end

---@class EffectGen: Thing
---@field parent Slab|nil ***read-only*** The Slab it belongs to.
if not EffectGen then EffectGen = {} end

---Destroys the object, triggers onObjectDestroyed if applicable.
function Object:destroy() end

--- @param action function|string the function to call when the event happens
function Thing:OnDamage(action)
    RegisterThingDamageEvent(action,self)
end

--- @param action function|string the function to call when the event happens
function Object:OnDestroyed(action)
    RegisterObjectDestroyedEvent(action,self)
end

----functions below are implemented in C, so they have no body here

---checks wether the given thing still exists
---@return boolean
---@nodiscard
function Thing:isValid() return false end

function Thing:delete() end

---sets the velocity of the thing
---@param speed integer speed / the distance it moves every tick
---@param orientation? integer 0-2047, the angle to move in the X/Y plane.
---@param pitch? integer 0-2047, the angle to move in the Z plane
function Thing:set_velocity(speed,orientation,pitch) end
