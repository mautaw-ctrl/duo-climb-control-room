-- Builtins.lua
-- Entry points for engine-triggered events (e.g. OnPowerCast, OnGameTick).
-- These functions are called by the C engine and dispatch event data to the Lua trigger system.

---@alias event_type "PowerCast"|"Death"|"SpecialActivated"|"GameTick"|"ChatMsg"|"DungeonDestroyed"|"TrapPlaced"|"ApplyDamage"|"LevelUp"|"PickUp"|"Slap"|"Rebirth"|"CreatureFellIntoAbyss"|"SlabKindChange"|"SlabOwnerChange"|"RoomOwnerChange"|"ShotHitThing"|"Destroyed"

--- Called when a spell is cast on a unit
--- @param pwkind power_kind
--- @param caster Player
--- @param target_thing Creature
--- @param stl_x integer
--- @param stl_y integer
--- @param splevel integer
function OnPowerCast(pwkind, caster, target_thing, stl_x, stl_y, splevel)
    local eventData = {}
    eventData.Thing = target_thing
    eventData.PowerKind = pwkind
    eventData.Player = caster
    eventData.stl_x = stl_x
    eventData.stl_y = stl_y
    eventData.splevel = splevel
    ProcessEvent("PowerCast",eventData)
end

--- Called when a unit dies
--- @param unit Creature The unit that dies
function OnCreatureDeath(unit)
    local eventData = {}
    eventData.unit = unit
    ProcessEvent("Death",eventData)
end

--- Called when an object is destroyed
--- @param object Object The object that is destroyed
function OnObjectDestroyed(object)
    local eventData = {}
    eventData.object = object
    ProcessEvent("Destroyed",eventData)
end

--- Called on each game tick to process timer events
function OnGameTick()
    local eventData = {}
    eventData.CurrentTurn = PLAYER0.GAME_TURN
    ProcessEvent("GameTick",eventData)
end

--- Called when a special box is activated
--- @param player Player
--- @param crate_thing Thing
function OnSpecialActivated(player,crate_thing,special_box_id)
    local eventData = {}
    eventData.Thing = crate_thing
    eventData.Player = player
    eventData.SpecialBoxId = special_box_id
    ProcessEvent("SpecialActivated",eventData)
end

--- @param player Player
--- @param message string
function OnChatMsg(player,message)
    local eventData = {}
    eventData.Player = player
    eventData.Message = message
    ProcessEvent("ChatMsg",eventData)
end

--- @param trap Thing The newly placed trap
function OnTrapPlaced(trap)
    local eventData = {}
    eventData.Trap = trap
    ProcessEvent("TrapPlaced",eventData)
end

--- @param player Player The player who lost
function OnDungeonDestroyed(player)
    local eventData = {player = player}
    ProcessEvent("DungeonDestroyed",eventData)
end

--- Called when a thing took damage
---@param thing Thing
---@param damage integer
---@param dealing_player Player
function OnApplyDamage(thing, damage, dealing_player)
    local eventData = {}
    eventData.thing = thing
    eventData.damage = damage
    eventData.dealing_player = dealing_player
    ProcessEvent("ApplyDamage",eventData)
end

--- Called when a creature levels up
---@param creature Creature
function OnLevelUp(creature)
    local eventData = {}
    eventData.creature = creature
    ProcessEvent("LevelUp",eventData)
end

--- Called when a thing is picked up. Can be Creatures, Chickens, Specials, Gold, etc.
---@param thing Thing
---@param player Player
function OnPickUp(thing, player)
    local eventData = {}
    eventData.thing = thing
    eventData.player = player
    ProcessEvent("PickUp",eventData)
end

--- Called when a thing is slapped. Can be Creatures, Traps, Shots, Objects, etc.
---@param thing Thing
---@param player Player
function OnSlap(thing, player)
    local eventData = {}
    eventData.thing = thing
    eventData.player = player
    ProcessEvent("Slap",eventData)
end

--- Called when a unit resurrects from his rebirth ability (like a vampire)
--- @param unit Creature The unit that rises from the death with 1xp level less
function OnCreatureRebirth(unit)
    local eventData = {}
    eventData.unit = unit
    ProcessEvent("Rebirth",eventData)
end

function OnCreatureFellIntoAbyss(unit)
    local eventData = {}
    eventData.unit = unit
    ProcessEvent("CreatureFellIntoAbyss",eventData)
end

--- Called when a slab changed
---@param slab Slab
---@param old_slab_kind slab_type
function OnSlabKindChange(slab, old_slab_kind)
    local eventData = {}
    eventData.Slab = slab
    eventData.old_slab_kind = old_slab_kind
    ProcessEvent("SlabKindChange",eventData)
end

--- Called when a slab owner changed
---@param slab Slab
---@param old_owner Player
function OnSlabOwnerChange(slab, old_owner)
    local eventData = {}
    eventData.Slab = slab
    eventData.old_owner = old_owner
    ProcessEvent("SlabOwnerChange",eventData)
end

--- Called when a room changes owner
---@param room Room
---@param old_owner Player
function OnRoomOwnerChange(room, old_owner)
    local eventData = {}
    eventData.Room = room
    eventData.old_owner = old_owner
    ProcessEvent("RoomOwnerChange",eventData)
end

--- Called when a shot hits a thing
---@param shot Shot the shot hitting something.
---@param shooter Thing|nil the shooter of the shot.
---@param target Thing|nil what was hit, will be nil if the shot hit a wall. 
---@param next_stl_x integer where the shot would have been had it not hit something. Useful if the shot hit a wall.
---@param next_stl_y integer where the shot would have been had it not hit something. Useful if the shot hit a wall.
---@param rebound_hit boolean true if the target was under the effect of rebound and the shot was not rebound immune.
function OnShotHit(shot, shooter, target, next_stl_x, next_stl_y, rebound_hit)
    local eventData = {}
    eventData.shot = shot
    eventData.shooter = shooter
    eventData.target = target
    eventData.next_stl_x = next_stl_x
    eventData.next_stl_y = next_stl_y
    eventData.rebound_hit = rebound_hit
    ProcessEvent("ShotHitThing",eventData)
end
